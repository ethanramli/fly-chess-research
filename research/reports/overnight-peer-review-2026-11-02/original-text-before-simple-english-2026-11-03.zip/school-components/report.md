# School-components review — 2026-11-02

Independent role-separated report, committed here as a completed artifact, **no git commit**. No other overnight reviewer output read. Same-model role separation is not independent scientific replication. Applied academic-paper-reviewer evidence/objection criteria and ponytail connected-call-path review; user overrides panel machinery. Private checklist covered transient reset, persistent state, exact-key identity, readout arbitration, local memory bounds/interference, anatomical signs and claim attribution.

## Top blockers (two substantive concerns; no third manufactured)

### SC-01 — candidate preview is learning-enabled in the live pilot

**Severity:** blocking before any relevant chess run that reuses this path as frozen inference. **Classification:** methodological blocker, not a demonstrated bug against the pilot's explicitly learning-enabled presentation schedule. Confidence high for code, unmeasured for actual graph effect magnitude.

Anchor: `.codebase/scripts/neural-learning/compare-long-term-memory-v1.mjs:146`, with `observe` at 110–119 and `gap` at 121. SHA-256 is in `source-hashes.json` and the finding record. Flow: `block` enumerates candidates → `peek` scores → `observe(1)` updates local state → `gap` advances another four units → next candidate. `LocalCubicReservoirMemory.observe` updates traces, four-state masses, gains, time and pulses; `setMagnitude` immediately changes signed runtime weights. Candidate scores therefore need not describe one common snapshot. Even with no gain change, persistent clock and trace change are certain in enabled arms.

Small counterexample: the actual pure cubic step with default threshold/trace, eta=2, k=1 and excess=.1 moves an initially strong-buffer gain from 1 to .872955216483345 and trace from 0 to .8646647167633873. A second candidate's score depending on that edge now observes another memory state. This is a sufficient possibility witness, not a claim that those exact DAN deviations occurred in the saved graph run.

Affected claim: frozen unaided rankings, candidate-order-independent choice, attribution of online differences to chosen consequence feedback alone. Tests cover the step and restore, while pilot arithmetic replay reproduces the prescribed order; neither supplies a reverse-order comparison. Its read-only phase `test` does preserve local/external fingerprints, so this objection does **not** invalidate those endpoint snapshots.

Self-challenge: protocol-v1 explicitly allocates observation and gap slots to both candidates; intentional exposure plasticity is legitimate for that assay. Thus do not label its completed result fraudulent or discard it. The defect would be presenting/reusing this as frozen candidate inference. The separate `record-neuron-candidates.mjs:50–94` already provides a distinct guarded frozen route, calling `forward(..., null)` without teaching. Evidence to close: caller-level frozen-state and reversed-enumeration checks for the actual future chooser, with intentional preview learning separately declared. No graph run is needed merely to establish that software contract.

### SC-02 — exact recall supplies no cross-key inference, and masks the neural readout on hits

**Severity:** major claim threat. **Classification:** disclosed scope limitation and methodological blocker for transfer attribution; no confirmed production defect. Confidence high.

Anchors: `.codebase/src/neural-learning/memory-backed-policy-v1.mjs:6–9`; `.codebase/src/neural-learning/episodic-consequence-memory.mjs:18–31`; live caller `compare-long-term-memory-v1.mjs:95–100`. Exact hashes: `source-hashes.json`.

Flow: sparse cue canonicalization sorts complete index/current pairs → exact JSON string Map lookup → most recent event → known recall returns its signed value, irrespective of neuralValue. Unknown hybrid recall falls back to the neural score; memory-only returns zero. Check fixture confirms changing one amplitude from 1 to 1.000001 misses, and a known +1 returns +1 even with neuralValue=-100. Distinct overlapping cues are not collisions; identical complete descriptors are intentionally the same address. Stored evidenceHash is provenance, not a query context or board/history discriminator.

The live runner also stores its naive denominator in a Map keyed by original cue array objects. A newly constructed array with identical values has no baseline (`means(undefined)` fails). It currently only calls `peek` with the original eight saved objects: this is **not an exercised missing-key crash**, but demonstrates why the runner is not yet a general unfamiliar-candidate evaluator.

Affected claims: learned reasoning, unfamiliar-position transfer, incremental graph contribution. The live pilot's known-key success and 23/24 reversal choices cannot establish these. Current status and the recent prospective scope correctly acknowledge this. Existing tests deliberately verify exact recall/override; their success cannot establish a capability absent from the component. Closure requires evidence from an explicitly defined unfamiliar-key inference path and matched lookup/non-connectome controls. No biological memory repair is required by this concern.

## Anatomy, runtime and rejected findings

- `SparseTrainer.forward:87–133` resets h[0] by default and overwrites subsequent states, using sparse signed CSR accumulation. Row-normalized log-count weights, bias .01, leak sigmoid(0)=.5 and finite eight-step dynamics are computational choices. No evidence here that head backprop is invoked by the pilot; the head is unused for its MBON score. Reject “SparseTrainer implies supervised learning” as a false positive.
- Cubic memory is explicitly labeled an uncalibrated hypothesis. Pure-step tests pass probability conservation, gain bounds, reversal and exact fresh restore. No verified source makes its cubic exponent, thresholds, DAN tonic .75 or model units physiological measurements. This is already disclosed; engineered-condition reasoning tests need attribution controls, not mandatory physiological repair. No new finding of biological deception established.
- MBON05 root mapping is preserved at indices 46203/95882. Prior sign receipt traces a left-cell ACH fallback and right-cell GLUT label; runtime faithfully retains opposite signs. Primary Aso Table 1 identifies MBON05 as gamma4>gamma1gamma2 in the glutamatergic group, and Fig17 supports cross-compartment projections. Neither establishes a receptor-resolved universal output sign or a chess score coefficient. Opposite signs remain a disclosed biological-validity concern, not proof of a broken computational experiment. I did not regenerate the large-table join or sign sensitivity graph results.
- The five-synapse anatomical cutoff cannot itself justify dynamical fidelity. Conversely, restoring all weak edges is not automatically correct. No threshold sensitivity claim is accepted from static counts alone. The passive reader guards roster and explicit score contracts; it does not manufacture validated biological valence.
- The interference-limits report confines its certificate to a fixed shared-baseline family and explicitly preserves the static feasible counterexample. I found no basis here to convert that into impossibility for all gains, all engineered memories or living flies. Full mathematical certificate replay is outside this component check.

## Verification, evidence limits and mistakes

Commands from repository root (no dependencies, propagation, training or sealed data):

`node --max-old-space-size=256 research/reports/overnight-peer-review-2026-11-02/school-components/check.mjs`

Result: passed; exactAmplitudeMiss=true, knownRecallMasksNeural=true, gain=.872955216483345, trace=.8646647167633873.

`node --max-old-space-size=256 --test .codebase/tests/neural-learning/episodic-consequence-memory.test.mjs .codebase/tests/neural-learning/memory-backed-policy-v1.test.mjs .codebase/tests/neural-learning/local-cubic-reservoir-memory.test.mjs .codebase/tests/neural-learning/neuron-reader.test.mjs`

Result: 14/14 pass, 0 failures; duration 267.4306ms. The test's 15,000 pure arithmetic transitions are not graph experiments. RSS/free-memory peaks were not instrumented; these bounded fixtures allocate no full graph. No memory-performance claim follows.

Read current status, approved restart, five-volume plan, recent eLife prospective README and interference-limits README; live protocol, results metrics and audit-v1 receipt; component sources, actual live caller, sparse runtime and relevant tests. Audit receipt reports 720 trials/4280 local frames/3318 graph forwards and explicitly does not independently regenerate graph responses. I inspected that receipt, not reran its whole audit. Raw graph trajectory and all old mechanism variants were not exhaustively rechecked.

Search for `15000|15,000|run15` in documentation, journal and report Markdown found no identified discarded checkpoint audit/smoke-run15 evidence. Availability remains unresolved; researcher recollection is not reconstructed as fact. Archive contents were not edited or exhaustively searched. No sealed/final inputs accessed.

Review mistakes: initial Windows wildcard rg paths failed; retried with file discovery. Guessed audit.json/config/eyes-candidate paths did not exist; located actual audit-v1.json and recorder. Those failures supply no scientific evidence. No production edits, shared navigation changes, git commits, or runs launched.

**Run disposition:** keep frozen chess evaluation on the live pilot scoring loop blocked pending SC-01's contract evidence; keep reasoning/graph-benefit claims blocked on SC-02's missing transfer evidence. This report establishes no reason to block a correctly registered engineered-memory experiment merely because biological memory remains unresolved. Other prerequisite/approval gates remain the parent's responsibility.
