# Primary methodology: problems-only review

2026-11-02. Solo role-separated review; no other reviewer outputs read. No graph propagation, training, sealed data, shared edits, commits or publication. Findings identify missing evidence, not permission to run. Source hashes and machine-readable records are in findings.json. Same-model reviewer roles are not scientific replication.

Private domain checklist used: observable task truth; independent chosen consequence; frozen candidate comparisons; lookup versus transfer; component attribution; game/seed/family sampling; sealed selection; proof domain. Relevant reviewer/ponytail criteria applied without panel machinery.

## Top blockers and scope

1. PM-01: live online rankings compare different persistent snapshots. Block reuse of this training loop for a common-snapshot chess experiment.
2. PM-02: exact memory provides no learning-dependent cross-key transfer with physiology frozen. Block a transfer run premised on that mechanism until the actual transfer path is declared and checked.
3. PM-03: Phase B/C remain outlines/proposals, without executable falsification thresholds or a test of the researcher's full definition. Block B/C confirmation; this does not block a separately registered one-relation development study.

## PM-01 — candidate observation changes the learner before its next candidate

**Confirmed implementation behavior; major claim threat; high confidence.** compare-long-term-memory-v1.mjs:145-147 invokes `peek(code); observe(1); gap()` for each candidate. `observe` at 103-118 calls LocalCubicReservoirMemory.observe; local-cubic-reservoir-memory.mjs:26-42 changes traces, reservoir state, potentially gain/effective edges, and time. Thus the second score is computed after first-candidate updates; selection combines scores from different learners. The fresh chosen `peek` at 156 occurs after both updates. In contrast, phase tests at 129-137 use peek without observe and assert unchanged state.

Trigger: the first informative saved trial already contains changing state in choice-stage frames. checks.json preserves its before/after hashes; seven of the trial's frame transitions change state. This establishes unequal snapshots, not the magnitude of a resulting accuracy bias. A simple counterexample to the measurement assumption is a readout whose second candidate's score changes after the first candidate's trace/gain update: reversing enumeration can change the winner without any new consequence evidence. No claim is made that the saved winner actually flips.

Affected evidence: online 95/96 acquisition and 12/24 versus 23/24 reversal trajectories, and causal interpretation of live policy comparisons. Final 4/4 phase tests are not invalidated by this specific issue. The protocol explicitly observes both candidates, so this is not undisclosed teacher leakage; however the results cannot be treated as a ranking from one persistent snapshot under the restart contract.

Existing checks miss it: memory-backed-policy-v1.test.mjs tests fixed numerical arbitration and external snapshot restore, not this runner's candidate loop. The live auditor validates each recorded score and replays intervening frames; consistency with the executed algorithm cannot establish the omitted common-snapshot invariant.

Evidence to close: a bounded state/ordering check of the actual selected runner showing identical full persistent identity across every candidate score, or an explicit prospective sequential-observation estimand with evidence separating order exposure from feedback learning. No graph rerun was performed here. Objection: sequential sensory exposure could be intentional. Accepted; that narrows the result to that sequential algorithm rather than rescuing common-snapshot attribution.

## PM-02 — exact recall plus frozen physiology has no cross-key learning path

**Disclosed scope limitation and methodological blocker, not a production defect; high confidence.** episodic-consequence-memory.mjs:31-35 queries only exact serialized sparse cues; memory-backed-policy-v1.mjs:7-10 returns recalled value on a hit and neural fallback on a miss. The live runner at 91-100 passes the frozen sparse relay code directly to that query. The saved-trace replay likewise stores chosen fixture cues; it does not execute a new policy trajectory. This correctly implements the declared engineering component.

Counterexample: train positive and negative episodes at keys A/B, then evaluate unseen key C with the same frozen neural state. Changing either episode consequence leaves C's score identical. A changed board sharing A is a hit/collision, not proof of learned relational transfer. The prospective protocol:15-17 proposes freezing physiology; :27-37 correctly recognizes this obstruction and proposes a different nearest-neighbour component, which is not the inspected exact-key implementation.

Affected claim/run: unfamiliar-position learning-dependent transfer attributed to the current engineered store, especially the proposed frozen-graph route. The current live report explicitly denies reasoning and incremental neural benefit; it does not cross its scope. Existing exact-recall and reversal checks intentionally reuse keys, so passing them cannot answer this question.

Evidence to close: pinned executable cross-key query behavior and unseen-cue fixture showing chosen feedback changes unseen predictions, with collision/retrieval coverage and identical-controller raw/rewired controls. Alternatively evidence of transferable neural learning would supply the missing path. Engineered memory remains permitted; repairing fly physiology is not required. Objection: exact lookup could generalize through invariant descriptors. Accepted, but descriptor invariance and conflicting-label aliases must be measured rather than inferred from lookup accuracy.

## PM-03 — the reasoning endpoint is not yet an executable test

**Acknowledged specification gap; blocking before B/C confirmation; high confidence.** restart-plan:26-33 defines many unrelated concepts; :171-179 leaves B/C to later addenda and explicitly calls two concepts minimal, not many. elife-prospective-protocol:78-80 supplies candidate tasks and appropriate cautions, while :88-90 leaves numerical B/C approval and endpoint aggregation outstanding. No inspected live runner implements these tasks: its four arbitrary associations and one reversal use assigned labels, not conjunctions of independently learned chess consequences.

Counterexample: a controller receives two trained classifiers and always applies hand-coded AND. It can beat either single classifier on specially selected conjunction items without learning to identify or combine concepts itself. Another counterexample is a test suite where the best single criterion solves almost all items; aggregate combined accuracy then says little about composition. These are rival explanations, not discovered hidden implementations.

Missing pre-run evidence: a fixed concept inventory and operational distance from 'unrelated'; independently certified necessity of each concept on the combination items; declared untaught combinations and split units; component/controller-only comparisons; and numerical effects/uncertainty/stopping thresholds. For the full definition, two related chess concepts cannot silently become many unrelated ones. Existing Phase A thresholds cannot be borrowed for this different estimand. Lake/Baroni shows why small-distribution generalization and systematic composition need separate tests; it does not provide chess thresholds.

Code may be correct while method is insufficient: the exact pilot produces valid association measurements, but those outputs do not instantiate B/C. The prospective report already says this. Closure is an approved, executable falsifiable B/C registration with bounded fixture certificates and frozen analysis, not more repetitions of the pilot. Objection: B/C are intentionally later. Accepted; this is a future-run gate, not criticism that unfinished phases have falsely passed.

## Challenges that did not survive

- **Interference proof overreach:** dismissed for the current report. A fresh VM execution of its BigInt checker (shared writes intercepted) verifies all certificate arithmetic/pins. Its theorem fixes recorded endpoints and candidate denominators, varies one shared baseline, and excludes that family only. Six-tuple restoration is explicitly a counterexample to an all-state strict-ranking impossibility. No interval guarantee for real-arithmetic propagation or organism-wide impossibility follows, and the report says so.
- **Pseudoreplication/cherry-picked significance:** no confirmed bug in the inspected live report: one seed is descriptive; all six arms are reported; no bootstrap superiority is asserted. The proposed analysis correctly clusters games and distinguishes seed variation from fly replication. Bootstrap implementation for future A/B/C was not found in the inspected neural-learning paths; resampling details remain registration work. The reported chance tail for 44/60 recomputes to 0.019702%, consistent with 0.02%; this does not validate joint-gate power.
- **Matched exposure:** own-choice opportunity counts are matched, chosen histories are not. The live report discloses this and does not infer a pure neural learning-rate gain. Memory-only's shadow graph is not a graph-independent perception control, also disclosed. The prospective protocol adds raw/rewired controls and common-exposure sensitivity; these have not run.
- **Unknowns:** synthetic pilot unknowns occur deterministically every eighth trial, not from exhausted chess proof. `online.correct` counts all trials and `knownTrials` counts certifiable ones; that is not itself a denominator bug. It cannot estimate selection effects when chess verification unknowns correlate with complexity. Prospective reporting asks for unknown fractions, but no actual chess unknown-denominator analysis was checked.

## Coverage and unavailable evidence

Read AGENTS, restart A/B/C/gates, five-volume series, current status, recent scope/prospective documents, live protocol/runner/auditor/policy/tests, external memory/replay path, interference report/checker/certificate receipts. Streamed only through the first live trial for state-transition reproduction; did not load large JSONL whole. Read-only source/receipt checks cannot verify full graph responses. No source edits, full suite, final/sealed inspection, new biological literature review, eLife-policy adjudication or test-family generator validation.

Targeted searches for `15000`, `15,000`, `run15` in current goal documents, journal and the two memory reports found no surviving artifact identifying the researcher's discarded checkpoint audit or clue-heavy smoke run. A journal match concerns 15,000 microseconds and is irrelevant. Those two historical episodes remain unavailable/recollection in this review; neither is reconstructed as fact. Archive content was not inspected or changed.

Small bounded check: `node --max-old-space-size=256 research/reports/overnight-peer-review-2026-11-02/primary-methodology/checks.mjs` passed, no graph imports/forwards. Own sources ledger records the narrow external reading. No reviewer outputs were consulted. No commit was made because the explicit verification rules prohibit git commits.
