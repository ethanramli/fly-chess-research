# Morning brief

**Open [ranked-problems.md](ranked-problems.md) before planning another chess run.** Four reviews are complete. Ten reviewer findings reduce to eight distinct issues. No fixes or training ran.

## The four most immediate problems

1. **The input can hide the answer.** A capture and a quiet move can look identical to the learner but get opposite verified labels. More repetitions cannot restore missing information. Applies to the inspected candidate-only route, not every possible learner.
2. **The audit can pass an empty evaluation.** Matching records are insufficient if required examples are absent. The negative predicate test passes with zero items; this does not mean the historical pilot was empty.
3. **The launch route can skip pause/ownership checks.** A learning comparison was labeled a check. The bounded preflight reproduction reports ready despite pause and competing-work inputs. No actual competing run was launched.
4. **Candidates are not always scored from the same memory.** The live training loop changes memory between candidate looks. Final read-only rankings remain distinct and are not invalidated by this finding.

## Four design gaps remain

1. The eye-test strength gate assumes a gain outside the inspected default learner's range and still needs its score contract.
2. The promised en-passant-recapture family cannot occur after this task's initial capture.
3. Exact lookup alone does not explain learning-dependent transfer to a different key.
4. The later combination/reasoning test is not yet an executable registered endpoint.

**The research question stays reasoning-first.** We are not redirecting the project into fixing fly memory. These are obstacles to a credible test of reasoning, not proof that reasoning is impossible. The mathematical baseline-repair contradiction survived the audit within its narrow stated scope.

Every issue in the [ranked file](ranked-problems.md) links to code, reviewer evidence, uncertainty and what must be demonstrated before that path is trusted. The separate literature ledgers are reachable from the [review index](README.md). This is a focused AI-assisted review, not independent scientific validation or a guarantee of no remaining bugs.

**Next action: read R01 in the ranked file (about two minutes).** It shows why the actual observation/label contract must be settled before spending compute on candidate-only all-legal learning. No implementation solution was chosen overnight.
