# Primary feedback audit — 2026-11-02

Read-only review. Role separation, not independent experimental replication. No training, graph propagation, sealed-data access, production changes, dependencies or git commits. User scope supersedes panel workflows. Applied ponytail-review and academic-paper-reviewer evidence criteria; no extra reviewers.

Private domain checklist used: certificate binding/perspective/unknown; prefeedback information; replay versus propagation; publication/pending receipt; restore/pins; CLI pause/serialization. This report concerns the computational reasoning objective. Biological memory repair is not a prerequisite imposed here.

## Priority blockers

1. PF-01: do not use this auditor as the sole gate for a relevant next chess experiment: incomplete evaluations can pass.
2. PF-02: block fresh full-graph runs through this comparison's `run compare` registration until pause/serial preflight is demonstrated.

Only two substantive defects found. Third-ranked concern is a disclosed limitation, not an additional defect: separate receipt arithmetic cannot establish that the graph produced its recorded activities. No current reasoning result is established.

## PF-01 — incomplete evaluation arrays satisfy the independent audit

**Severity:** blocking before any relevant chess run relying on this audit. **Class:** confirmed validation bug. **Confidence:** high for predicate failure; whole-run forged publication not executed.

**Anchor:** `.codebase/scripts/neural-learning/audit-long-term-memory-v1-live.mjs:127-147,163`; SHA256 `39cdc4b7c197f4d7fcfa7b0e67ba92b360358b4e9bc3924f4a59a0c5d6fb627b`.

**Actual flow:** CLI reads manifest/summary/records, streams each arm's frames, validates test rows with `r.tests.forEach`, compares snapshots against these rows, compares records against reconstructed tests, and evaluates `tests[p].every(x => x.correct)`. Neither the test branch nor the final comparison requires four items. Output reports 144 evaluations as a constant rather than a checked counter.

**Trigger:** an empty `tests` list in each phase, matching empty snapshot/record lists, and recomputed summary/records manifest digests. All item checks are skipped and the joint predicate returns true. A less sweeping case removes a failing final item and matching snapshot/record item; remaining items keep their correct indices. Producer output hashes provide consistency, not an externally fixed expected cardinality. Frame hashes are calculated by the auditor from whatever it receives. This is an incomplete-artifact/fabrication acceptance path, not evidence anyone fabricated historical results.

**Checks:** `checks.mjs` executes the literal extracted test-validation block and joint predicate from current auditor source: zero validations, true joint pass. It does not import the CLI. `checks-result.json` records command/result. Existing first informative saved record has all four items in all six phases; that spot check rebuts any claim this defect proves the saved pilot result false. No whole audit or multi-file mutation was run.

**Why existing checks miss it:** policy/memory tests test arithmetic and state round trips, not missing evaluation records. Agreement among reduced summary, snapshot and receipt arrays still satisfies equality. The reported count is hardcoded.

**Affected claim:** complete independent verification of all item evaluations; any downstream gate trusting the same completeness predicates. **Closure evidence:** bounded negative audit fixture that removes a failed item or all items, updates producer-owned digests consistently, and is rejected specifically for missing required coverage. Confirm actual observed evaluation count against the registered fixture, without executing a learner.

## PF-02 — graph learner registered as an unguarded check

**Severity:** blocking before any relevant fresh run through this registration. **Class:** confirmed control-path bug. **Confidence:** high.

**Anchors:** `python actions/long-term-memory-v1-live-pilot-v1-step.json:45-57`, SHA256 `3efcdb7846d69f5c1d242e682ac742f8a66f181cca56915f186667e8d812e7c7`; `python actions/curriculum.py:308-355,571`, SHA256 `f084dd00fe3976948b2a96dbb79c65c74c07c80392361d273192b3496bf4cb52`; `.codebase/scripts/neural-learning/compare-long-term-memory-v1.mjs:18-39,77-82`, SHA256 `b1aa1bc85d0cffff46cf90f069fd3e3588f6af6b351e24e8f36e66264b3476b5`.

**Actual flow:** action `run compare` resolves a job with `role: check`, routes to foreground execution, and calls `plan`. Its `if job['role'] != 'check'` excludes pause, live-process serialization and heap/duty preflight for this job. The command actually constructs SparseTrainer, propagates the full graph, and changes both memory states. The runner's own guard checks RSS/free memory/time/forward count, but never pause or competing graph ownership.

**Trigger/check:** `check-guards.py` compiles the actual `plan` AST with matching-pin/fresh-path mocks, sets paused true and supplies busy/zero-free-memory inventory. It still returns ready. No process launches. The initial check failed because the isolated namespace omitted ROOT; adding ROOT corrected the harness, and `guard-result.json` records the passing counterexample. This test-harness error does not diagnose production behavior.

**Objection tested:** the real completed directory exists, and refuse_existing prevents relaunch now. That protects that artifact, but does not provide pause/serialization protection in the registered fresh-run lifecycle. Current config is unpaused; no assertion is made that the completed pilot violated authorization or overlapped another run. Changing an already frozen registration would also break pins: closure must preserve the historical record.

**Why existing checks miss it:** valid pins and refusal to overwrite are tested separately from a graph-producing command labeled check. Source pins faithfully pin the bypass. **Affected contract:** Python actions are safe to invoke while research is paused and graph experiments remain serial. **Closure evidence:** a fresh-output preflight fixture for this exact graph command rejects paused state and a competing live/unknown graph process; demonstrate launch dispatch cannot bypass that decision. No new training is needed.

## Correct code / insufficient method; dismissed false positives

- The live comparison's certificate is explicitly `assigned-action-association-v1`; runner lines 149-164 bind chosen/good moves and the auditor lines 100-107 checks FEN/moves/criterion/scope/known against pinned source fixtures. This is sufficient for its declared arbitrary association assay, not chess consequences. Treating absence of chess proof here as a current production defect would be false. A future chess claim cannot inherit this evidence.
- Auditor lines 60-70 recompute a scalar from supplied response/baseline arrays; replayFrame reconstructs local memory from logged KC/DAN activity. Neither independently propagates the graph. Coherent false activity could survive that boundary; README and audit output explicitly disclose it. No claim-crossing bug established. For graph-causal reasoning claims, independently checked propagation/interventions remain missing evidence.
- Episodic commit explicitly delegates verification to callers. Any hex evidence hash alone can be committed, by design; this is not a certificate verifier. Live caller and replay auditor do bind synthetic labels. Unknown commits return without modifying external memory. Neural activity can still change under intrinsic dynamics during unknown/absent trials; current README discloses that distinction.
- Episodic restore validates checksum/config, recency, event sequence and terminal fingerprint before assigning private state. Duplicate latest-event commit is rejected. No duplication counterexample established on this call path.
- Live runner publishes both memories and pending receipt before appending its trial record (lines 115-122,166). There is no implemented recovery CLI; checkpoint says so and README disclaims automatic/power-loss recovery. Rename without fsync must not be promoted to durable power-loss evidence, but that scope limit is disclosed. Shared storage save/load was inspected; its legacy supervised checkpoint format is not used by this live pilot. Do not transfer a legacy-format concern to this caller without evidence.
- Mate checker v2 verifies exact FEN/PGN/actor/horizon and required legal alternatives, maps replay exceptions/budget exhaustion to unknown. Avoid-mate wrapper reverses opponent perspective explicitly. Sequence replay rechecks branch certificates and describes illustrative contexts rather than biological delayed credit. These are inspected modules, not evidence the current live association CLI calls them: it does not.

## Coverage and limits

Read current status, approved restart plan, five-volume design, recent eLife/interference report scope, live protocol/README, current runner and auditor, episodic implementation/tests, Python replay auditor, action registration/preflight/dispatch excerpts, runtime storage/publication tests, mate/avoid-mate checkers and sequence replay. Reports are background assertions, challenged against connected code. Proposed scope changes remain proposals; exact recall is not unfamiliar concept combination, and no simulation result establishes living-fly reasoning.

Bounded saved evidence: first live records row (six phases each contain four items), first audit metadata/publication hashes. No full saved receipt replay, no independent graph responses, no OS crash injection, no complete restart dependency audit, no exhaustive older search/certificate caller audit. No sealed/final families. Other overnight reviewer folders were not read. Source and report files only were read outside this owned folder.

A targeted search of current status/journal/live report for `15000`, `15,000`, `run15` found no matching discarded-checkpoint/smoke evidence; one unrelated 15,000-microsecond pacing note is not that evidence. Those claims remain user recollection/unavailable within checked scope. Archives were not scanned or modified. Do not infer what the deleted audit measured.

Checks are tiny predicate fixtures, not full-system replication. No full suite or graph run was launched. Parent owns any broader serialized verification. No production fix is supplied. Evidence and closure requirements are the deliverable.
