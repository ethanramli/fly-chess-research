# Primary source ledger — accessed 2026-11-02

Implementation findings PF-01/PF-02 derive from local primary source code, exact hashes/locators and literal predicate checks in report.md. No paper is needed to establish Python branch behavior or empty-array semantics. Local saved result coverage is explicitly bounded there.

**Thanumalayan Sankaranarayana Pillai, Vijay Chidambaram, Ramnatthan Alagappan, Samer Al-Kiswany, Andrea C. Arpaci-Dusseau, Remzi H. Arpaci-Dusseau (2014). All File Systems Are Not Created Equal: On the Complexity of Crafting Crash-Consistent Applications.** https://www.usenix.org/conference/osdi14/technical-sessions/presentation/pillai

- Verified primary conference landing page; read title/authors/abstract/bibliography, web lines 84-118. Full paper not read.
- Supports the narrow caution that application persistence correctness depends on filesystem persistence properties, so atomic publication and crash durability need separate evidence.
- Limits: study concerns Linux filesystems; does not prove a failure on this Windows installation or establish Node/NTFS semantics. Accordingly no crash-durability defect is filed against the expressly limited pilot.
- Search terms: none; direct primary-source URL open for focused persistence scope check. Access succeeded; no download or access failure.

No broad literature/novelty search. No claims of first/novel. No manuscript was transmitted to outside AI providers. Literature cannot substitute for verification of current call paths.
