# Overnight code and methodology review

Status: all four reviews complete; parent evidence checks and synthesis complete. Ten reviewer findings merge into eight distinct issues. No fixes, gate amendments or learner runs.

Researcher authority, 2026-11-02: reasoning-first under the stated constraints; problems only; no production fixes. Two school-account and two primary-account GPT-6.1 Sol reviewers, all **medium** reasoning effort (supersedes the initial high-effort request). Each inspects a separate scope and writes a separate primary-source literature ledger. No training or learner experiments.

## Assignments

1. `school-input`: input/encoding leakage, board/history observability, task and dataset construction.
2. `school-components`: neural dynamics, memory, readout, graph identities and biological assumptions.
3. `primary-feedback-audit`: consequence verification, teaching pathway, persistence/recovery and audit validity.
4. `primary-methodology`: experimental controls, attribution, reasoning/transfer definitions, statistics and proof claims.

Reviewers write only inside their own folders and do not read each other's reviews before committing their reports. Account/model separation is not independent biological or scientific validation. The parent will inspect evidence, adjudicate disagreements and publish a ranked master issue ledger and an ADHD-friendly morning brief. Implementation and training remain outside scope.

## Completed deliverables

- [Ranked problems](ranked-problems.md): eight issues, code/evidence links, limits and exact run blockers.
- [Morning brief](morning-brief.md): short explanation and first action.
- [Parent adjudication](parent-adjudication.md): verification, duplicate merges and interpretation limits.
- Reviews: [input](school-input/report.md), [components](school-components/report.md), [feedback/audit](primary-feedback-audit/report.md), [methodology](primary-methodology/report.md).
- Separate literature ledgers: [input](school-input/sources.md), [components](school-components/sources.md), [feedback/audit](primary-feedback-audit/sources.md), [methodology](primary-methodology/sources.md). Each directory also contains finding records and reproduction checks.

Read [verification receipt](verification.json) for file/link/hash/check scope. This is a focused review, not certification that every component or future methodology is sound. AI assisted all reviews and synthesis.
