# Ranked code and methodology problems

2026-11-02. **Problems-only handoff: no fixes implemented and no learner experiment authorized.** Four GPT-6.1 Sol medium-effort reviewers, two school and two primary, produced ten findings; parent review merges two overlapping pairs into **eight distinct issues**. Priority follows dependency and risk of wasting the next experiment, not a count of reviewer votes. Same-model roles and accounts do not supply independent scientific replication. The target remains reasoning under the researcher's definition and computational constraints; biological memory repair is not a prerequisite for the engineered condition.

## Read this first

The present candidate-only input can erase a fact the teacher labels; the evaluation auditor can pass empty coverage; the comparison launch registration skips pause/ownership preflight; and its online scores do not share one frozen memory snapshot. These four concerns need closure before reusing those paths for the corresponding chess experiment. Separate blockers remain in the eye protocol, one promised test family, the transfer mechanism and the reasoning endpoint. None proves the historical pilot fabricated results, the model cannot ever reason, or a living fly has a general memory limit.

## 1. The learner can receive identical observations with opposite correct answers

**ID R01 = SI-01. Confirmed input/task mismatch; highest priority for candidate-only all-legal learning.**

Evidence: [input report SI-01](school-input/report.md), [real-retina counterexample and source pins](school-input/checks.json), [reproduction](school-input/check.mjs). Source: [Eyes renderer](../../../.codebase/src/chess-input/eyes-v1.mjs:89), [task labels](../../../.codebase/src/search-and-feedback/capture-retention-action-domain.mjs:29).

The renderer applies the candidate action and supplies the resulting board with source/destination marks. It removes the captured piece before the learner sees it. Two pre-boards, differing only by a black pawn on a4, with action a1a4 produce the same 308-entry stimulus and SHA256 f230ef69723a2976cc6e9f64d2423ddec802bd8fa1f70ed6baca7ae79d141350. On one board this is a verified safe capture; on the other it is a verified quiet-task failure. Parent reran the actual receptor-map encoding and both independent task checks.

**Why it threatens the result:** no deterministic scorer receiving only this stimulus and identical memory can give opposite answers. More training or exact lookup cannot reconstruct erased information. This is a cross-component contract failure, not a renderer arithmetic error.

**Limit:** the pair was constructed, not found inside sealed/generated data; it does not prove aggregate pass gates impossible. A policy receiving a previous-board observation or other candidates may have more information. Capture-only decoder diagnostics are unaffected. **Blocked:** promoting this candidate-only route to all-legal quiet-versus-capture learning without an adequate observation contract. **Closure evidence:** actual learner-visible observations distinguish the counterexample, and a bounded end-to-end observation/label check covers the registered task. No code solution is selected here.

## 2. The audit can pass without evaluating the required items

**ID R02 = PF-01. Confirmed validation defect.**

Evidence: [feedback/audit report PF-01](primary-feedback-audit/report.md), [predicate check receipt](primary-feedback-audit/checks-result.json). Source: [auditor](../../../.codebase/scripts/neural-learning/audit-long-term-memory-v1-live.mjs:127).

The auditor loops over supplied evaluation lists but does not require four items. Its joint-pass predicate uses `.every`, which is true on an empty list. Matching empty lists in receipts, records and snapshots can satisfy consistency without satisfying coverage; producer-owned digests do not add the missing coverage condition. The reported 144 item evaluations is a formula, not an observed counter. Parent reran the literal extracted predicates: zero item validations and a true joint predicate.

**Why it threatens the result:** an incomplete result could receive a completeness pass, undermining the audit as a gate for expensive future work. **Limit:** no whole-run multi-file forgery was executed; historical inspected pilot rows contain four items. This does not falsify that pilot. **Blocked:** relying on this auditor alone for complete required evaluation coverage. **Closure evidence:** a negative fixture removes all items or a required failing item, keeps artifacts mutually consistent, and the real audit rejects missing registered coverage.

## 3. A learning run is classified as an unguarded check

**ID R03 = PF-02. Confirmed registration/control-path defect.**

Evidence: [feedback/audit report PF-02](primary-feedback-audit/report.md), [actual-plan AST reproduction](primary-feedback-audit/check-guards.py), [receipt](primary-feedback-audit/guard-result.json). Sources: [comparison registration](../../../python%20actions/long-term-memory-v1-live-pilot-v1-step.json:45), [action preflight](../../../python%20actions/curriculum.py:319).

The comparison does full-graph propagation and learning but is registered with role `check`. The action preflight excludes that role from pause, competing-process and free-memory checks. Parent reran its actual `plan` function under matching-pin/fresh-path mocks: it reports ready despite paused state and busy/zero-free-memory inventory.

**Why it threatens the result:** correct pins do not prevent a new invocation from running during a pause or alongside competing work. **Limit:** current completed-output refusal protects the historical directory; the runner has separate runtime resource guards. The mock does not establish any past overlap, authorization breach or actual launch. **Blocked:** fresh graph invocations through this classification pattern. **Closure evidence:** fresh-output dispatch for this graph-producing command rejects paused and competing/unknown graph owners without launching a process.

## 4. Candidate scores can come from different memory states

**ID R04 = PM-01 + SC-01. Confirmed behavior; methodological blocker for frozen comparisons.**

Evidence: [methodology PM-01](primary-methodology/report.md), [component SC-01](school-components/report.md), [saved-state reproduction](primary-methodology/checks.json). Source: [live candidate loop](../../../.codebase/scripts/neural-learning/compare-long-term-memory-v1.mjs:146).

The loop scores candidate one, observes it and advances memory, then scores candidate two. The local updater changes traces, reservoir state, time and potentially effective graph weights. Parent inspected both call paths and reran the saved first-trial check; seven state transitions change local state. The component arithmetic witness additionally demonstrates possible gain change.

**Why it threatens the result:** online ranking is not a comparison from one frozen persistent snapshot; enumeration and intervening exposure may affect choices. **Limit:** the pilot intentionally declared this observation schedule. No actual winner flip or bias size was measured. Final read-only phase rankings preserve fingerprints and are not invalidated by this concern. The separate guarded frozen recorder is a different path. **Blocked:** reusing the pilot loop as frozen unaided chess scoring or attributing its trajectory solely to chosen feedback. **Closure evidence:** actual future chooser checks complete state equality across candidates and reverse ordering, or prospectively defines a sequential-observation question instead.

## 5. The complete eye-test gate is not executable as interpreted

**ID R05 = SI-02. Previously disclosed protocol blocker, not a new regression.**

Evidence: [input report SI-02](school-input/report.md); [original gate](../../../documentation/design/research-goals/restart-plan-2026-10-30.md:144). The gate imposes a gain corner of 1.8, whereas inspected default physiological candidates cap at 1. A complete deployed behavioral score contract is also unresolved. An imposed oracle corner can measure an accessibility bound but cannot establish endogenous attainability or useful deployed scoring.

**Why it threatens the result:** a diagnostic pass can answer a different question from the permission-to-advance gate. **Limit:** configurable alternative bounds and engineered memory are possible different conditions; no universal gain impossibility is inferred. **Blocked:** the complete registered eye test/advancement using this interpretation. **Closure evidence:** an explicitly approved prospective condition and attainable-state/score contract. Preserve original thresholds and history; no amendment is enacted by this review.

## 6. One promised locked family cannot occur under the task definition

**ID R06 = SI-03. Previously disclosed unresolved specification defect.**

Evidence: [input report SI-03 and FIDE source](school-input/report.md), [source ledger](school-input/sources.md). The original family asks for en-passant recapture after an initial capture. En passant requires the immediately preceding move to be a double pawn push, not a capture. The certificate also identifies recaptures by arrival on the moved piece's target; en passant removes a pawn elsewhere.

**Why it threatens the result:** a generator cannot supply the promised family honestly; silently substituting another family changes the locked transfer question. **Limit:** initial en-passant capture followed by ordinary recapture is a different possible family, not proof the original exists. **Blocked:** generating/sealing or claiming completion of the original full family allocation. **Closure evidence:** accepted family semantics and real-history development generator/checker receipts before sealing. No final files were opened.

## 7. Exact recall does not provide cross-key learning-dependent transfer

**ID R07 = PM-02 + SC-02. Disclosed capability gap, not a broken lookup implementation.**

Evidence: [methodology PM-02](primary-methodology/report.md), [components SC-02](school-components/report.md), [arithmetic check](school-components/check.mjs). Sources: [exact query](../../../.codebase/src/neural-learning/episodic-consequence-memory.mjs:31), [policy arbitration](../../../.codebase/src/neural-learning/memory-backed-policy-v1.mjs:7).

Known exact recall replaces the neural score. An unseen key falls back to neural scoring (or zero for memory-only); changing another key's episode does not affect that fallback if neural state is frozen. Parent reran the amplitude-miss/override fixture. The memory-only baseline still shares graph-derived descriptors, so it is not a fully graph-independent perception comparator.

**Why it threatens the result:** perfect familiar recall can look like improvement without evidence of unfamiliar-concept application or incremental neural decision benefit. **Limit:** invariant descriptors can map new boards to old keys; learned neural changes could provide another route. Neither is established by exact recall alone. **Blocked:** a transfer run premised solely on the exact store plus frozen physiology. **Closure evidence:** a pinned executable transfer pathway and unfamiliar-key causal test with controller/retrieval/non-connectome comparisons. A proposal for nearest-neighbour retrieval is not implemented evidence and is not adopted here. Biological repair is not demanded.

## 8. The reasoning endpoint is still an outline

**ID R08 = PM-03. Acknowledged future-stage specification gap.**

Evidence: [methodology PM-03](primary-methodology/report.md), [restart B/C](../../../documentation/design/research-goals/restart-plan-2026-10-30.md:171). The researcher requires applying many unrelated concepts to an unfamiliar problem. B/C still need approved executable tasks, numeric endpoints, split/aggregation rules and stopping criteria. Two related chess concepts are explicitly a minimal test, not the full definition.

**Why it threatens the result:** a hard-coded conjunction of separately trained classifiers can beat single-concept arms without the learner identifying and combining concepts. A family solvable by one concept also cannot establish combination. These are rival explanations, not discovered hidden code. **Blocked:** B/C confirmation, not a correctly registered one-relation development study. **Closure evidence:** executable falsifiable registration, certificates that each concept is needed, untaught combination splits and attribution controls. Do not borrow Phase A thresholds automatically.

## What this review did not establish

- No confirmed label-dependent marker-brightness leak, current split contamination, wrong root mapping, fabricated historical result or general biological incapacity. Dataset duplication/family disjointness were not empirically cleared; final sets stayed sealed.
- The restricted baseline contradiction certificate survived checking. Its actual assumptions are explicit; a feasible six-tuple restoration still rules out the stronger all-state strict-ranking impossibility claim.
- Disclosed arbitrary-association feedback is valid for that scope, not a chess consequence certificate. Same-session local arithmetic replay does not independently reproduce graph propagation.
- The researcher's deleted approximately 15,000-checkpoint audit and smoke-run15 could not be identified in scoped surviving evidence. They remain unverified recollections, not reconstructed findings.
- This is a focused pre-run review, not a guarantee that the whole codebase or methodology is free of defects. No full suite, sealed evaluation, new learner run or whole-graph replication occurred.

## Closure order for the next chat

First establish an adequate learner-visible task contract (R01), fail-closed evaluation coverage (R02), launch ownership/pause enforcement (R03), and the actual frozen chooser contract (R04). Then resolve the specific eye/family registration blockers R05/R06. Before transfer or reasoning experiments, require explicit closure evidence for R07/R08. A concern blocks the named path/claim, not every read-only or separately authorized research activity. This is an evidence dependency order, not permission to implement or launch.

Full attribution: [parent adjudication](parent-adjudication.md), [input sources](school-input/sources.md), [component sources](school-components/sources.md), [feedback sources](primary-feedback-audit/sources.md), [methodology sources](primary-methodology/sources.md). Reading is narrow: several external records are abstract-only and one neuroscience retrieval failed. Source-specific limits remain in those ledgers; there is no novelty or journal-readiness certification. AI assisted all four reviews and this synthesis.
